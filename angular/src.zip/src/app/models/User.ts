export class User {

  constructor(
      public apellido1:string,
      public apellido2:string,
      public cp:string,
      public direccion:string,
      public email:string,
      public nombre:string,
      public nombre_usuario:string,
      public pass:string
  ){}

}
